

$(function(){
    $('#btn_remove').click(function () {
        $("#dataTableBody").empty();
        $("#dataTableBody_deatil").empty();
        $('#map').empty();
        
        
    });
});