document.addEventListener('scroll', function(){
    let current = document.documentElement.scrollTop;
    let colorValue = Math.round(current/4);
    let selector = document.getElementsByClassName('menu_bar_selector');


    
})